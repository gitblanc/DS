/**
 * 
 */
package gui;

import model.Line;

/**
 * 
 */
public interface BotonAlineacion {

	void dibujaTexto(Line line);

}

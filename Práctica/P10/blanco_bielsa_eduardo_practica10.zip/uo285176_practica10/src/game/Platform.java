/**
 * 
 */
package game;

/**
 * @author UO285176
 *
 */
public enum Platform {
	ANDROID, WINDOWS, PLAYSTATION;
}

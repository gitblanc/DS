/**
 * 
 */
package editor.actions;

/**
 * @author blanc
 *
 */
public interface Action {

	void execute();

	void undo();

}

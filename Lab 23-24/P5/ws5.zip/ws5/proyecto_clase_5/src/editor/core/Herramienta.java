package editor.core;

public interface Herramienta {
	public void pinchar(int x, int y);
	public void mover(int x, int y);
	public void soltar(int x, int y);
}

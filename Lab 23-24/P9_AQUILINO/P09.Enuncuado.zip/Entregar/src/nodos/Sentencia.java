package nodos;

public interface Sentencia extends Nodo {
    
}

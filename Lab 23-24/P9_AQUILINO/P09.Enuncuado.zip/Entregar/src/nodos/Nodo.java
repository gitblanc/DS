package nodos;

public interface Nodo {

}

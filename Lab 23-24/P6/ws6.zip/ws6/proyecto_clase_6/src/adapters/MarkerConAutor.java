package adapters;

public interface MarkerConAutor {

	public String getAutor();

	public String getDirección();

	public void setAutor(String texto);

	public void setDirección(String texto);
}

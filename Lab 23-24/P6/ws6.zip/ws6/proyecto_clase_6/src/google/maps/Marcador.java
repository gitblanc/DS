package google.maps;

public interface Marcador {
	Coordenadas getCoordenadas();

	String pulsaciónCorta();

	void pulsaciónLarga();

//	String getAutor();
//
//	String getDirección();
//
//	void setAutor(String texto);
//
//	void setDirección(String texto);
}

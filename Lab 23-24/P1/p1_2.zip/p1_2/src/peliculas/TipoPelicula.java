package peliculas;

import videoclub.Alquiler;

public interface TipoPelicula {

	int getPuntos(Alquiler alquiler);

	double getPrecio(Alquiler alquiler);

}

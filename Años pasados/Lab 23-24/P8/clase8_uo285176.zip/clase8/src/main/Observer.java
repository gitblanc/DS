package main;

import encuesta.Encuesta;

public interface Observer {
	void actualizar(Encuesta e);
}

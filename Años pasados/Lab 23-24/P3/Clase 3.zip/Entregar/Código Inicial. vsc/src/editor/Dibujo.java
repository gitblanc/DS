package editor;

import java.util.*;

public class Dibujo {

	/*
	public addFigura(...) {
		// TO DO
	}
	*/

	public void dibujar() {
		// Dibujar las figuras que contenga
	}

}

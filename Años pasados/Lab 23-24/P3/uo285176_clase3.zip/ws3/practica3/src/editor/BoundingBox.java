/**
 * 
 */
package editor;

/**
 * @author blanc
 *
 */
public class BoundingBox {

}

package tools;

import editor.Editor;

public class TriangleTool implements Tool {

	public TriangleTool(Editor editor) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void soltar(int x, int y) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mover(int x, int y) {
		// TODO Auto-generated method stub

	}

	@Override
	public void pinchar(int x, int y) {
		// TODO Auto-generated method stub

	}

	@Override
	public String toString() {
		return "herramienta de creación de Triángulo";
	}
}

package tools;

import editor.Editor;

public class RectangleTool implements Tool {
	
	private Editor editor;
	
	private BoundingBox boundingBox;

	public RectangleTool(Editor editor) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void soltar(int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mover(int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pinchar(int x, int y) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public String toString() {
		return "herramienta de creación de Rectángulo";
	}

}

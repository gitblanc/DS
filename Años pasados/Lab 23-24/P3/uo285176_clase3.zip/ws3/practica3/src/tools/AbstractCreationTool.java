package tools;

public abstract class AbstractCreationTool implements Tool {

	@Override
	public void soltar(int x, int y) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mover(int x, int y) {
		// TODO Auto-generated method stub

	}

	@Override
	public void pinchar(int x, int y) {
		// TODO Auto-generated method stub

	}

}

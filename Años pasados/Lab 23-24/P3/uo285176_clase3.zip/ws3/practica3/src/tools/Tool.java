package tools;

public interface Tool {

	void soltar(int x, int y);

	void mover(int x, int y);

	void pinchar(int x, int y);

}

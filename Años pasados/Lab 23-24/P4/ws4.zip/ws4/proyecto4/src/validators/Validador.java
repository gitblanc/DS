package validators;

public interface Validador {
	public boolean isValid(String value);
}

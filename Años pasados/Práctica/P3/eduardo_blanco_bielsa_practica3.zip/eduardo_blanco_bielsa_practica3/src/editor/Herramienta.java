package editor;

public interface Herramienta {
	public void pulsar(int x, int y);
	public void mover(int x, int y);
	public String getType();
	public String infoHerramienta();
}

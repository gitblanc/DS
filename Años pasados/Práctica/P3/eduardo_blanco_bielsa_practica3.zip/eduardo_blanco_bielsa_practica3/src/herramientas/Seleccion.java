package herramientas;

import editor.Herramienta;

public class Seleccion implements Herramienta{

	@Override
	public void pulsar(int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mover(int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getType() {
		return "Herramienta de selección";
	}

	@Override
	public String infoHerramienta() {
		return "seleccion";
	}

}

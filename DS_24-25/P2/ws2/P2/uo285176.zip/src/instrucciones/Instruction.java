package instrucciones;

import main.Estado;

public interface Instruction {
	public void execute(Estado estado);
}

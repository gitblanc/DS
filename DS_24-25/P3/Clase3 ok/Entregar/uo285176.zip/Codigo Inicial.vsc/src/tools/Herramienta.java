package tools;

public interface Herramienta {
	void pinchar(int x, int y);
	void mover(int x, int y);
	void soltar(int x, int y);
	void unselect();
}

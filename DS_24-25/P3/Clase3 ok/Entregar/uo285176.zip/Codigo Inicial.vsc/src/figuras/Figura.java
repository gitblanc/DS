package figuras;

public interface Figura {

	void dibujar();

	boolean contiene(int x, int y);

	void mover(int x, int y);

}

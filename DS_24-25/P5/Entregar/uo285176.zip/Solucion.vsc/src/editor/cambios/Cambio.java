package editor.cambios;

public interface Cambio {

	void redo();

	void undo();

}

package editor.actions;

import editor.Document;

public interface Action 
{
	void execute(Document document);
}

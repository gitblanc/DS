package formulario;

public interface Campo {
    public void pideDato();

    public String getDato();
}

package formulario;

public interface Validacion {
	boolean isValid(String texto);
}

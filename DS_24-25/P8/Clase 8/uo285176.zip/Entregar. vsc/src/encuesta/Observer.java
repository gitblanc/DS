/**
 * 
 */
package encuesta;

/**
 * 
 */
public interface Observer {
	void notificar(Encuesta encuesta);
}

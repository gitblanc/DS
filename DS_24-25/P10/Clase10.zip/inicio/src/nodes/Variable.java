package nodes;

public class Variable implements Expression {

    // NOTA: deberían ser private con getters y setters, pero se dejan públicos para agilizar la clase
    public String name;

    public Variable(String name) {
        this.name = name;
    }

}

package nodes;

public interface Statement extends Node {

}

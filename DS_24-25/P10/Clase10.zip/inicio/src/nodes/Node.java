package nodes;

public interface Node {
}

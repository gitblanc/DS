package nodes;

public class Input implements Statement {

    // NOTA: deberían ser private con getters y setters, pero se dejan públicos para agilizar la clase
    public Variable variable;

    public Input(Variable variable) {
        this.variable = variable;
    }

}

package nodes;

public interface Expression extends Node {

}

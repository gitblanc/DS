package google.maps;

public interface Marcador {
    Coordenadas getCoordenadas();

    String pulsaciónCorta();

    void pulsaciónLarga();
}
